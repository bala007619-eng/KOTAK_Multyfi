# Multyfi Kotak Approval — Android source prototype

This is a notification capture and manual review prototype. It does not place, modify, or cancel orders. The Approve button only records `APPROVED — NOT SENT`; Reject records `REJECTED`.

## Build
Open this folder in Android Studio, sync Gradle, install Android SDK 35 if prompted, then choose Build > Build APK(s). Install the resulting debug APK on your Android phone.

## Setup
1. Launch the app.
2. Select Multyfi in the app list and tap Save selected app.
3. Open notification access settings and enable access for this app.
4. Return to the app. Incoming notifications from the selected app will be captured and shown in the local list.
5. Approve or Reject records only your local decision.

## Important limitations
- Notification parsing depends on the text that Multyfi actually places in Android notifications. The parser recognizes common labels; compare the captured raw notification with the displayed fields.
- This prototype has no Kotak API integration and does not send any order.
- Kotak Neo order APIs require a whitelisted static IP and a session created from that same IP under current requirements. A mobile-only app should not contain API secrets or attempt to bypass those controls. A compliant backend may be required for actual order submission.
- Never share API tokens, TOTP, MPIN, or session credentials.


## Build an APK with GitHub Actions

1. Create a **private** repository on GitHub.
2. Upload the contents of this folder (including the hidden `.github` folder) to the repository's `main` branch.
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. If it does not start automatically, choose **Run workflow**.
5. When the workflow finishes successfully, open the run and download the `MultyfiKotakApproval-debug-apk` artifact. Unzip it to get the APK.

This produces a debug APK for testing, not a Play Store release. The app only records approval locally; it does not place broker orders.
