package com.example.multyfikotakapproval

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class AlertListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val prefs = getSharedPreferences("approval_app", MODE_PRIVATE)
        val source = prefs.getString("source_package", null) ?: return
        if (sbn.packageName != source) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        val big = extras.getCharSequence("android.bigText")?.toString().orEmpty()
        val lines = extras.getCharSequenceArray("android.textLines")
            ?.joinToString("\n") { it.toString() }.orEmpty()
        val body = listOf(big, lines, text).firstOrNull { it.isNotBlank() }.orEmpty()
        AlertStore.add(this, SignalParser.parse(title, body))
    }
}
