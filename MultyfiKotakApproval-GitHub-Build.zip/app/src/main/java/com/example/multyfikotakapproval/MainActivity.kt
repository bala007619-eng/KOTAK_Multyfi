package com.example.multyfikotakapproval

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppChoice(val label: String, val pkg: String) {
    override fun toString() = label
}

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var spinner: Spinner
    private val prefs by lazy { getSharedPreferences("approval_app", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
        }
        scroll.addView(content)
        setContentView(scroll)
        build()
    }

    override fun onResume() { super.onResume(); build() }

    private fun build() {
        content.removeAllViews()
        content.addView(TextView(this).apply {
            text = "Multyfi Kotak Approval"
            textSize = 24f
            setPadding(0,0,0,10)
        })
        content.addView(TextView(this).apply {
            text = "Notification review prototype. Approve/Reject currently records your choice locally only; no order is sent."
            textSize = 14f
            setPadding(0,0,0,14)
        })
        content.addView(TextView(this).apply {
            text = "Notification access: " + if (hasAccess()) "ENABLED" else "NOT ENABLED"
            textSize = 16f
            setPadding(0,4,0,8)
        })
        content.addView(Button(this).apply {
            text = "Open notification access settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        content.addView(TextView(this).apply {
            text = "Choose notification app"
            textSize = 16f
            setPadding(0,12,0,4)
        })
        spinner = Spinner(this)
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { AppChoice(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
            .toMutableList()
        val saved = prefs.getString("source_package", null)
        val idx = apps.indexOfFirst { it.pkg == saved }
        val likely = apps.indexOfFirst { it.label.contains("multyfi", true) || it.pkg.contains("multyfi", true) }
        if (idx < 0 && likely >= 0) {
            val a = apps.removeAt(likely); apps.add(0,a)
        }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, apps)
        if (idx >= 0) spinner.setSelection(idx)
        content.addView(spinner)
        content.addView(Button(this).apply {
            text = "Save selected app"
            setOnClickListener {
                val selected = spinner.selectedItem as? AppChoice ?: return@setOnClickListener
                prefs.edit().putString("source_package", selected.pkg)
                    .putString("source_label", selected.label).apply()
                build()
            }
        })
        content.addView(Button(this).apply {
            text = "Clear history"
            setOnClickListener { AlertStore.clear(this@MainActivity); build() }
        })
        content.addView(TextView(this).apply {
            text = "Captured alerts"
            textSize = 20f
            setPadding(0,18,0,8)
        })
        val alerts = AlertStore.all(this)
        if (alerts.isEmpty()) {
            content.addView(TextView(this).apply { text = "No alerts captured yet."; textSize = 15f })
        }
        alerts.forEach { alert ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14,14,14,14)
                setBackgroundColor(0xFFF1F5F9.toInt())
            }
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(alert.receivedAt))
            card.addView(TextView(this).apply {
                text = "${alert.symbol.ifBlank { "Unknown stock" }}  •  ${alert.action.ifBlank { "Unknown action" }}"
                textSize = 18f
            })
            card.addView(TextView(this).apply {
                text = "Entry: ${alert.entry.ifBlank { "Not detected" }}\nSL: ${alert.stopLoss.ifBlank { "Not detected" }}\nTarget: ${alert.target.ifBlank { "Not detected" }}\nProduct: ${alert.product.ifBlank { "Not detected" }}\nReceived: $time\nStatus: ${alert.status}\n\nOriginal notification:\n${alert.title}\n${alert.raw}"
                textSize = 13f
                setPadding(0,8,0,8)
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this@MainActivity).apply {
                text = "Approve"
                isEnabled = alert.status == "PENDING"
                setOnClickListener {
                    AlertStore.update(this@MainActivity, alert.copy(status="APPROVED — NOT SENT"))
                    build()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this@MainActivity).apply {
                text = "Reject"
                isEnabled = alert.status == "PENDING"
                setOnClickListener {
                    AlertStore.update(this@MainActivity, alert.copy(status="REJECTED"))
                    build()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(row)
            content.addView(card)
            content.addView(TextView(this).apply { text = " " })
        }
    }

    private fun hasAccess(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val target = ComponentName(this, AlertListenerService::class.java).flattenToString()
        return enabled.split(":").any { it.equals(target, true) }
    }
}
