package com.example.multyfikotakapproval

import org.json.JSONObject
import java.util.UUID

data class Alert(
    val id: String = UUID.randomUUID().toString(),
    val receivedAt: Long = System.currentTimeMillis(),
    val title: String,
    val raw: String,
    val symbol: String = "",
    val action: String = "",
    val product: String = "",
    val entry: String = "",
    val stopLoss: String = "",
    val target: String = "",
    val status: String = "PENDING"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("receivedAt", receivedAt); put("title", title)
        put("raw", raw); put("symbol", symbol); put("action", action)
        put("product", product); put("entry", entry); put("stopLoss", stopLoss)
        put("target", target); put("status", status)
    }
    companion object {
        fun fromJson(j: JSONObject) = Alert(
            id=j.optString("id", UUID.randomUUID().toString()),
            receivedAt=j.optLong("receivedAt", System.currentTimeMillis()),
            title=j.optString("title"), raw=j.optString("raw"),
            symbol=j.optString("symbol"), action=j.optString("action"),
            product=j.optString("product"), entry=j.optString("entry"),
            stopLoss=j.optString("stopLoss"), target=j.optString("target"),
            status=j.optString("status", "PENDING")
        )
    }
}

object AlertStore {
    private const val PREFS = "approval_app"
    private const val KEY = "alerts"
    fun all(context: android.content.Context): MutableList<Alert> {
        val raw = context.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        val arr = org.json.JSONArray(raw)
        return MutableList(arr.length()) { i -> Alert.fromJson(arr.getJSONObject(i)) }
    }
    @Synchronized fun add(context: android.content.Context, alert: Alert) {
        val list = all(context)
        if (list.none { it.id == alert.id }) list.add(0, alert)
        save(context, list.take(100))
    }
    @Synchronized fun update(context: android.content.Context, alert: Alert) {
        val list = all(context)
        val idx = list.indexOfFirst { it.id == alert.id }
        if (idx >= 0) list[idx] = alert
        save(context, list)
    }
    @Synchronized fun clear(context: android.content.Context) = save(context, emptyList())
    private fun save(context: android.content.Context, list: List<Alert>) {
        val arr = org.json.JSONArray()
        list.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }
}

object SignalParser {
    private fun field(text: String, vararg labels: String): String {
        for (label in labels) {
            val r = Regex("(?im)^\\s*${Regex.escape(label)}\\s*:\\s*(.+?)\\s*$")
            r.find(text)?.let { return it.groupValues[1].trim() }
        }
        return ""
    }
    fun parse(title: String, body: String): Alert {
        val all = "$title\n$body"
        return Alert(
            title=title,
            raw=body,
            symbol=field(all, "Stock", "Symbol", "Underlying"),
            action=field(all, "Action", "Signal", "Trade"),
            product=field(all, "Product", "Segment"),
            entry=field(all, "Entry Range", "Entry", "Entry Price"),
            stopLoss=field(all, "Stop Loss (SL)", "Stop Loss", "SL"),
            target=field(all, "Target 1", "Target", "TP")
        )
    }
}
